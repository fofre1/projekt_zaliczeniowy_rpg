﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KulkiPrzeszkody
{
    public class Gra
    {
        protected GeneratorPlanszy generatorPlanszy;
        protected Gracz gracz;
        protected Wizualizacja wizualizacja;
        private bool koniec = false;
        private Plansza plansza;
        private List<Kulka> kulki = new();
        private (float, float) pozycjaStartu;
        PriorityQueue<Zdarzenie, DateTime> kolejka = new();

        private void Uruchom()
        {
            koniec = false;
            kulki.Add(new Kulka());
            while (!koniec)
            {
                plansza = generatorPlanszy.Generuj();
                (float, float) kierunek = gracz.Kierunek();
                Start(kierunek);
            }
        }

        private void Start((float, float) kierunek)
        {
            // 1. Dodanie do kolejki zdarzeń startu kulek
            foreach (var kulka in kulki)
                kolejka.Enqueue(new StartKulki(kulka, kierunek, pozycjaStartu), DateTime.Now);
            // 2. Pętla obsługi zdarzeń - pobieramy, realizujemy
            while (kolejka.Count > 0)
            {
                Zdarzenie zdarzenie;
                DateTime czas;
                kolejka.TryDequeue(out zdarzenie, out czas);
                if (czas > DateTime.Now)
                    Thread.Sleep(czas - DateTime.Now);
                if (zdarzenie.Aktualne())
                    zdarzenie.Realizuj(kolejka, plansza);

            }
        }
    }
}
