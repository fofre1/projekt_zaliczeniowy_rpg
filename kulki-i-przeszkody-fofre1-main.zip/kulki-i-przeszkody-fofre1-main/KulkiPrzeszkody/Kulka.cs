﻿
namespace KulkiPrzeszkody
{
    public class Kulka
    {
        internal int ileZdarzenMinelo;
        internal (float, float) kierunek;
        internal (float, float) pozycjaStartu;

        internal void Start((float, float) pozycjaStartu, (float, float) kierunek)
        {
            this.kierunek = kierunek;
            this.pozycjaStartu = pozycjaStartu;
            ileZdarzenMinelo++;
        }
    }
}