﻿

namespace KulkiPrzeszkody
{
    public abstract class Zdarzenie
    {
        public abstract bool Aktualne();

        public abstract void Realizuj(PriorityQueue<Zdarzenie, DateTime> kolejka, Plansza plansza);
    }
}