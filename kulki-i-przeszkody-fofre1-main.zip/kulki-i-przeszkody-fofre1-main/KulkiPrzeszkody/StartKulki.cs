﻿
namespace KulkiPrzeszkody
{
    internal class StartKulki : Zdarzenie
    {
        private Kulka kulka;
        internal (float, float) kierunek;
        internal (float, float) pozycjaStartu;
        int stanKulki;
        public StartKulki(Kulka kulka, (float, float) kierunek, (float, float) pozycjaStartu)
        {
            this.kulka = kulka;
            this.kierunek = kierunek;
            this.pozycjaStartu = pozycjaStartu;
            stanKulki = kulka.ileZdarzenMinelo;
        }

        public override bool Aktualne()
        {
            return stanKulki == kulka.ileZdarzenMinelo;
        }

        public override void Realizuj(PriorityQueue<Zdarzenie, DateTime> kolejka, Plansza plansza)
        {
            kulka.Start(pozycjaStartu, kierunek);
            plansza.DodajPotencjalneZdarzenia(kulka, kolejka);
        }
    }
}