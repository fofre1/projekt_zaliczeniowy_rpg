﻿namespace KulkiPrzeszkody
{
    public class Gracz
    {

    }
}
