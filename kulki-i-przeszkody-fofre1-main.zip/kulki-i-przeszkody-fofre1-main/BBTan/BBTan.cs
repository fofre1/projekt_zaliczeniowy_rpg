﻿using KulkiPrzeszkody;

class BBTan : Gra
{
    

    public BBTan(GeneratorPlanszy generatorPlanszy, Gracz gracz, 
        WizualizacjaWKonsoli wizualizacja)
    {
        this.generatorPlanszy = generatorPlanszy;
        this.gracz = gracz;
        this.wizualizacja = wizualizacja;
    }

    static void Main(string[] args)
    {
        GeneratorPlanszy generatorPlanszy = new();
        Gracz gracz = new();
        WizualizacjaWKonsoli wizualizacja = new();
        BBTan gra = new(generatorPlanszy, gracz, wizualizacja);
        gra.Uruchom();
    }

    private void Uruchom()
    {
        
    }
}
